from pathlib import Path

parent_dir = Path(__file__).parent

MODEL_PATH = parent_dir / "osiriabert-italian-cased-ner"
FOLDER_PATH = parent_dir / "dataset"
ANON_FILE_PATH = r"C:\Users\BG726XR\ai-academy-1\Giorno_8\gruppo_1\file_anon" 
RESULTS_PATH = r"C:\Users\BG726XR\ai-academy-1\Giorno_8\gruppo_1\results"